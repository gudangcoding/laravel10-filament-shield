<?php

namespace App\Filament\Resources;

use App\Filament\Resources\SalesOrderResource\Pages;
use App\Filament\Resources\SalesOrderResource\RelationManagers;
use App\Filament\Resources\SalesOrderResource\RelationManagers\SalesDetailRelationManager;
use App\Models\Customer;
use App\Models\SalesOrder;
use Filament\Forms;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Grid;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use App\Filament\Resources\CustomerResource;
use App\Models\SalesDetail;
use Doctrine\DBAL\Schema\Schema;
use Filament\Forms\Components\Card;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\Placeholder;
use Filament\Support\Enums\MaxWidth;

class SalesOrderResource extends Resource
{
    protected static ?string $model = SalesOrder::class;
    protected static ?string $ownershipRelationship = "salesOrders";
    protected static ?string $tenantOwnershipRelationshipName = "team";
    protected static ?string $navigationGroup = "Marketing";
    protected static ?string $label = 'Sales Order';
    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

    public static function form(Form $form): Form
    {

        return $form
            ->schema([
                Section::make()
                    ->columns([
                        'sm' => 6,
                        'xl' => 6,
                        '2xl' => 8,
                    ])
                    ->schema([
                        Card::make('Data Pelanggan')
                            ->columnSpan([
                                'md' => 4,
                            ])
                            ->schema([
                                TextInput::make('so_no')
                                    ->label('No.SO')
                                    ->default('SO_' .  date('ymd') . "_" . str_pad(SalesOrder::max('id') + 1, 4, '0', STR_PAD_LEFT)),
                                Select::make('customer_id')
                                    ->label('Nama Pelanggan')
                                    ->placeholder('Pilih')
                                    ->searchable()
                                    ->options(Customer::all()->pluck('nama_customer', 'id')->toArray())
                                    ->reactive()
                                    ->afterStateUpdated(function ($state, callable $set) {
                                        // Mencari customer berdasarkan ID yang dipilih
                                        $customer = Customer::with(['kelas', 'kategori_customer'])->find($state);

                                        if ($customer) {
                                            // Mendapatkan class dan chanel dari customer
                                            $customerClass = $customer->kelas;
                                            $customerCategory = $customer->kategori_customer;

                                            // Mengupdate nilai customer_class_id dan customer_category_id
                                            $set('customer_class_id', $customerClass ? $customerClass->name : null);
                                            $set('customer_category_id', $customerCategory ? $customerCategory->name : null);
                                        } else {
                                            // Jika customer tidak ditemukan, set nilai ke null
                                            $set('customer_class_id', null);
                                            $set('customer_category_id', null);
                                        }
                                    })
                                    ->relationship('customer', 'nama_customer')
                                    ->createOptionForm(fn (Form $form) => CustomerResource::form($form) ?? [])
                                    ->editOptionForm(fn (Form $form) => CustomerResource::form($form) ?? [])
                                    ->createOptionAction(fn ($action) => $action->modalWidth(MaxWidth::FiveExtraLarge)),

                                TextInput::make('customer_class_id')
                                    ->label('Class')
                                    ->default(fn ($get) => optional(Customer::with('kelas')->find($get('customer_id')))->kelas?->name)
                                    ->readOnly(),

                                TextInput::make('customer_category_id')
                                    ->label('Kategori')
                                    ->default(fn ($get) => optional(Customer::with('kategori_customer')->find($get('customer_id')))->kategori_customer?->name)
                                    ->readOnly(),

                                DatePicker::make('tanggal')
                                    ->default(now())
                                    ->native(false)
                                    ->displayFormat('d/m/Y')
                            ])->columns(2),
                        Card::make('Total Bayar')
                            ->columnSpan([
                                'md' => 2,
                            ])

                            ->schema([

                                Placeholder::make('amounts')
                                    ->label('Total Belanja')
                                    ->reactive()
                                    ->content(function ($get) {
                                        $sum = SalesDetail::where('sales_order_id', $get('id'))->sum('subtotal');
                                        return number_format($sum) ?? 0;
                                        // $sum = 0;
                                        // foreach ($get('order_details') as $product) {
                                        //     $sum = $sum + ($product['harga'] * $product['qty']);
                                        // }
                                        // return $sum;
                                    }),
                                // TextInput::make('amounts')
                                //     ->label('Total Belanja')
                                //     ->live()
                                //     ->readOnly()
                                //     ->default(function ($get) {
                                //         $sum = SalesDetail::where('sales_order_id', $get('id'))->sum('subtotal');
                                //         return number_format($sum) ?? 0;
                                //     }),
                                Hidden::make('amount'),
                                TextInput::make('diskon')
                                    ->reactive()
                                    ->default(function ($get) {
                                        // Mengonversi nilai diskon dan ongkir ke tipe numerik
                                        $diskon = is_numeric($get('diskon')) ? $get('diskon') : 0;
                                        $ongkir = is_numeric($get('ongkir')) ? $get('ongkir') : 0;

                                        // Menghitung total belanja
                                        $totalBelanja = SalesDetail::where('sales_order_id', $get('id'))->sum('subtotal');

                                        // Memastikan total belanja tidak null
                                        if ($totalBelanja === null) {
                                            $totalBelanja = 0;
                                        }

                                        // Menghitung grand total
                                        $grandTotal = $totalBelanja - $diskon + $ongkir;

                                        // Mengembalikan grand total dalam format yang sesuai
                                        return number_format($grandTotal, 2, '.', '');
                                    })
                                    ->label('Diskon'),
                                TextInput::make('ongkir')
                                    ->reactive()
                                    ->default(function ($get) {
                                        // Mengonversi nilai diskon dan ongkir ke tipe numerik
                                        $diskon = is_numeric($get('diskon')) ? $get('diskon') : 0;
                                        $ongkir = is_numeric($get('ongkir')) ? $get('ongkir') : 0;

                                        // Menghitung total belanja
                                        $totalBelanja = SalesDetail::where('sales_order_id', $get('id'))->sum('subtotal');

                                        // Memastikan total belanja tidak null
                                        if ($totalBelanja === null) {
                                            $totalBelanja = 0;
                                        }

                                        // Menghitung grand total
                                        $grandTotal = $totalBelanja - $diskon + $ongkir;

                                        // Mengembalikan grand total dalam format yang sesuai
                                        return number_format($grandTotal, 2, '.', '');
                                    })
                                    ->label('Ongkir'),
                                //
                                TextInput::make('grand_total')
                                    ->reactive()
                                    ->default(function ($get) {
                                        // Mengonversi nilai diskon dan ongkir ke tipe numerik
                                        $diskon = is_numeric($get('diskon')) ? $get('diskon') : 0;
                                        $ongkir = is_numeric($get('ongkir')) ? $get('ongkir') : 0;

                                        // Menghitung total belanja
                                        $totalBelanja = SalesDetail::where('sales_order_id', $get('id'))->sum('subtotal');

                                        // Memastikan total belanja tidak null
                                        if ($totalBelanja === null) {
                                            $totalBelanja = 0;
                                        }

                                        // Menghitung grand total
                                        $grandTotal = $totalBelanja - $diskon + $ongkir;

                                        // Mengembalikan grand total dalam format yang sesuai
                                        return number_format($grandTotal, 2, '.', '');
                                    })
                                    ->label('Total'),

                            ])
                    ]),



            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('id')
                    ->searchable(),
                TextColumn::make('so_no')
                    ->searchable(),
                TextColumn::make('total_amount')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('total_barang')
                    ->numeric()
                    ->sortable(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
            SalesDetailRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListSalesOrders::route('/'),
            'create' => Pages\CreateSalesOrder::route('/create'),
            'edit' => Pages\EditSalesOrder::route('/{record}/edit'),
        ];
    }
}
