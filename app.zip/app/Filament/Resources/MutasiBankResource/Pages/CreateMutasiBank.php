<?php

namespace App\Filament\Resources\MutasiBankResource\Pages;

use App\Filament\Resources\MutasiBankResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMutasiBank extends CreateRecord
{
    protected static string $resource = MutasiBankResource::class;
}
