<?php

namespace App\Filament\Resources\DataAlamatResource\Pages;

use App\Filament\Resources\DataAlamatResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDataAlamat extends CreateRecord
{
    protected static string $resource = DataAlamatResource::class;
}
