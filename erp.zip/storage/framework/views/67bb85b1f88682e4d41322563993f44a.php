<div>
    <?php if (isset($component)) { $__componentOriginale1cebc129855f156aa8f78d22103aca1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale1cebc129855f156aa8f78d22103aca1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.breadcrumbs','data' => ['breadcrumbs' => [
        '/admin/mutasi-banks' => 'Mutasi Bank',
        '' => 'List',
    ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
        '/admin/mutasi-banks' => 'Mutasi Bank',
        '' => 'List',
    ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale1cebc129855f156aa8f78d22103aca1)): ?>
<?php $attributes = $__attributesOriginale1cebc129855f156aa8f78d22103aca1; ?>
<?php unset($__attributesOriginale1cebc129855f156aa8f78d22103aca1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale1cebc129855f156aa8f78d22103aca1)): ?>
<?php $component = $__componentOriginale1cebc129855f156aa8f78d22103aca1; ?>
<?php unset($__componentOriginale1cebc129855f156aa8f78d22103aca1); ?>
<?php endif; ?>
    <div class="flex justify-between mt-1">
        <div class="text-3xl font-bold">Form Import Mutasi</div>
        <div>
            <?php echo e($data); ?>

        </div>
    </div>
    <div>
        <!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <form wire:submit="save" class="flex w-full max-w-sm mt-2">
            <div class="mb-4">
                <label class="block mb-2 text-sm font-bold text-gray-700" for="fileInput">
                    Pilih Berkas
                </label>
                <input
                    class="w-full px-3 py-2 leading-tight text-gray-700 border rounded shadow appearance-none focus:outline-none focus:shadow-outline"
                    id="fileInput" type="file" wire:model='file'>
            </div>
            

            <div class="flex items-center justify-between mt-3">
                <button type="submit" class="bg-blue-500">
                    Unggah
                </button>
            </div>

        </form>
    </div>
</div>
<?php /**PATH C:\laragon\www\laravel10-filament-shield\resources\views/filament/custom/import.blade.php ENDPATH**/ ?>